# %% Ne pas modifier ######################

import test_tp2
import inspect
import os

os.chdir(os.path.dirname(os.path.abspath(inspect.getsourcefile(lambda: 0))))

###########################################
### I. Création de tableaux ###############

### Exercice 1


def alternance(n):
    ...


test_tp2.exercice1(alternance)

### Exercice 2


def sommes_des_préfixes(t):
    ...


# test_tp2.exercice2(sommes_des_préfixes)

### Exercice 3


def syracuse(a):
    ...


# test_tp2.exercice3(syracuse)

###########################################
### II. Chaînes de caractères #############

### Exercice 5


def est_présent_à(texte, motif, p):
    ...


# test_tp2.exercice5_1(est_présent_à)


def contient_motif(texte, motif):
    ...


# test_tp2.exercice5_2(contient_motif)

###########################################
### III. Plusieurs boucles ###############

### Exercice 6


def catalan(n):
    ...


# test_tp2.exercice6(catalan)

### Exercice 7


def distance_maximale(t, v):
    ...


# test_tp2.exercice7_1(distance_maximale)


def diamètre(t):
    ...


# test_tp2.exercice7_2(diamètre)

###########################################
### IV. Génération de nombres premiers ####

### Exercice 8


def ératosthène(n):
    ...


# test_tp2.exercice8(ératosthène)