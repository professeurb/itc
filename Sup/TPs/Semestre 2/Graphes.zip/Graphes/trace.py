# %% Ne pas modifier ######################

import csv
import matplotlib.pyplot as plt
import inspect
import os

os.chdir(os.path.dirname(os.path.abspath(inspect.getsourcefile(lambda: 0))))

###########################################

# %%

sommets = []

with open("sommets.csv") as csvfile:
    reader = csv.DictReader(csvfile, delimiter=";")
    for row in reader:
        sommets.append(row)

aretes = []

with open("aretes.csv") as csvfile:
    reader = csv.DictReader(csvfile, delimiter=";")
    for row in reader:
        aretes.append(row)

# %%

for tr in aretes:
    debut = sommets[int(tr["debut"])]
    fin = sommets[int(tr["fin"])]
    plt.plot(
        [float(debut["x"]), float(fin["x"])],
        [float(debut["y"]), float(fin["y"])],
        color=tr["couleur"],
    )

plt.scatter([float(point["x"]) for point in sommets], [float(point["y"]) for point in sommets])

plt.show()

# %%
